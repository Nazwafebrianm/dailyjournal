const menuBtn=document.getElementById("menuBtn");
const nav=document.getElementById("nav");
menuBtn.addEventListener("click",()=>{nav.classList.toggle("open");menuBtn.textContent=nav.classList.contains("open")?"✕":"☰"});
document.querySelectorAll("#nav a").forEach(a=>a.addEventListener("click",()=>{nav.classList.remove("open");menuBtn.textContent="☰"}));
const btn=document.getElementById("startWriting"),toast=document.getElementById("toast");
btn.addEventListener("click",()=>{toast.classList.add("show");setTimeout(()=>toast.classList.remove("show"),2400)});
