const menuBtn=document.querySelector(".menu-btn"),links=document.querySelector(".links"),startBtn=document.getElementById("startBtn"),toast=document.getElementById("toast");
menuBtn?.addEventListener("click",()=>links.classList.toggle("open"));
document.querySelectorAll(".links a").forEach(a=>a.addEventListener("click",()=>links.classList.remove("open")));
document.querySelectorAll('a[href^="#"]').forEach(a=>a.addEventListener("click",e=>{const target=document.querySelector(a.getAttribute("href"));if(target){e.preventDefault();target.scrollIntoView({behavior:"smooth"});}}));
startBtn?.addEventListener("click",()=>{toast.classList.add("show");setTimeout(()=>toast.classList.remove("show"),2600);});
