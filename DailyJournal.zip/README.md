# DailyJournal
Aplikasi digital journal berbasis HTML, CSS, dan JavaScript dengan tema navy + burgundy.

Fitur: journal CRUD, mood, prompt harian, pencarian, kalender, statistik, streak, LocalStorage, responsive, favicon.

Untuk GitHub Pages: upload semua file ke root repository, lalu Settings > Pages > Deploy from a branch > main > / (root).
Data journal disimpan lokal di browser perangkat yang digunakan.
